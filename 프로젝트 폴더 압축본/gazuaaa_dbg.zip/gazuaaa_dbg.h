#ifndef EX_DIALOGAPP_RC_H
#define EX_DIALOGAPP_RC_H

//--------------------------------------------------------------------
// ��ȭ���� ID

#define IDD_MAIN_DIALOG	101

//--------------------------------------------------------------------
// ��Ʈ�ѵ��� ID

#define IDC_PUSHBUTTON_OPENFILEDIALOG	201
#define IDC_LTEXT_FILETOBEOPENED		202
#define IDC_EDIT_FILETOBEOPENED			203

//--------------------------------------------------------------------

#endif
