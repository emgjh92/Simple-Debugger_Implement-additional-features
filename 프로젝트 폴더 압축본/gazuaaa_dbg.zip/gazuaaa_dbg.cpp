//-------------------------------------------------------------------------------------------------
// Header Files
#define _CRT_SECURE_NO_WARNINGS    // fopen ���� ����� ���� ������ ���� ����
#include <windows.h>
#include <stdio.h>
#include "udis86.h"  //�𽺾�������� ���� udis86.h
#include <time.h> //�α����� ���� �� ������ ����ϱ� ���� time.h

#pragma comment(lib, "libudis86.lib")//udis86�� ���̺귯�� ����

#include "gazuaaa_dbg.h"


//-------------------------------------------------------------------------------------------------
// Macro Definitions

//-------------------------------------------------------------------------------------------------
// Global Variables

HWND hButtonOpenFileDialog;		// ���Ͽ��� ��ȭ���ڸ� �����ϱ� ���� ��ư�� �ڵ�
HWND hEditFileToBeOpened;		// ������ ��ο� �̸��� �������� ����Ʈ ��Ʈ���� �ڵ�

OPENFILENAME OFN;					// ���Ͽ��� ��ȭ���ڸ� �ʱ�ȭ�ϱ� ���� ����
const UINT nFileNameMaxLen = 512;	// ���� �ٿ� �����ϴ� szFileName ���ڿ��� �ִ� ����
WCHAR szFileName[nFileNameMaxLen];	// ������ ��� �� �̸��� �����ϱ� ���� ���ڿ�

// Functions

BOOL CALLBACK MainDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam);


//==================================================================================================

int sj_disassembler(unsigned char *buff, char *out, int size)
{ //��� �����ϴ� ������ ����Ѵ�. ���⼭ udis86�� ����� ���ǰ� �ȴ�.
 
       ud_t ud_obj;
       ud_init(&ud_obj);
       ud_set_input_buffer(&ud_obj, buff, 32);
       ud_set_mode(&ud_obj, 32);
       ud_set_syntax(&ud_obj, UD_SYN_INTEL);
 
       if(ud_disassemble(&ud_obj)){
              sprintf_s(out, size, "%14s  %s", ud_insn_hex(&ud_obj), ud_insn_asm(&ud_obj));
       }else{
              return -1;
       }
       return (int)ud_insn_len(&ud_obj);
}
 
 
int exception_debug_event(DEBUG_EVENT *pde)
{ //exception�� �߻��ϸ� ����Ǹ�, ���� �Լ����� ȣ��
/* Open Process,ReadProcessMemory, OpenThread, GetThreadContext, SetThreadContext */

   // �� �Լ��� WriteProcessMemory number �� �ٸ� ���μ����� access �ϴµ� �ʿ�
	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
						FILE *fp = fopen("exception_temp.txt", "w+");
						if (fp == NULL) {
							fprintf(fp, "This is log file for exception case\n");
						}
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
       DWORD dwReadBytes;
 
       HANDLE process_hander= OpenProcess( // ���μ��� ���� , ��鷯�� �Ҵ�
              PROCESS_VM_WRITE | PROCESS_VM_READ | PROCESS_VM_OPERATION,
              FALSE, pde->dwProcessId);
       
       if(!process_hander) return -1;
 
       HANDLE thread_handler= OpenThread(THREAD_GET_CONTEXT | THREAD_SET_CONTEXT, FALSE, pde->dwThreadId);
              //Open Thread : Register ���� �б����� �ʿ��� function
       
       if(!thread_handler) return -1;
 
              CONTEXT ctx;
              ctx.ContextFlags= CONTEXT_ALL;
              GetThreadContext(thread_handler, &ctx);
             //GetThreadContext ����  �������͸� Read �� �� �ִ�.
              char asm_string[256];
              unsigned char asm_code[32];
 
       ReadProcessMemory(process_hander, (VOID *)ctx.Eip, asm_code, 32, &dwReadBytes);
                //exeception_debug_event �Լ����� exception�� �߻��Ҷ� ���� �� ������ ��� ���� �ʿ�

       if(sj_disassembler(asm_code, asm_string, sizeof(asm_string)) == -1)
       asm_string[0] = '\0';
      

   // ������ ����
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), 64);
		printf("  EventCode: %d ", pde->dwDebugEventCode);
		fprintf(fp,"  EventCode: %d ", pde->dwDebugEventCode);
								if(pde->dwDebugEventCode==1){
									printf(" EXCEPTION_DEBUG_EVENT     ");
									fprintf(fp," EXCEPTION_DEBUG_EVENT     ");
								}
								else if(pde->dwDebugEventCode==2){
									printf(" CREATE_THREAD_DEBUG_EVENT ");
									fprintf(fp," CREATE_THREAD_DEBUG_EVENT ");
								}
								else if(pde->dwDebugEventCode==3){
									printf(" CREATE_PROCESS_DEBUG_EVENT");
									fprintf(fp," CREATE_PROCESS_DEBUG_EVENT");
								}
								else if(pde->dwDebugEventCode==4){
									printf(" EXIT_THREAD_DEBUG_EVENT   ");
									fprintf(fp," EXIT_THREAD_DEBUG_EVENT   ");
								}	
								else if(pde->dwDebugEventCode==5){
									printf(" EXIT_PROCESS_DEBUG_EVENT  ");
									fprintf(fp," EXIT_PROCESS_DEBUG_EVENT  ");
								}
								else if(pde->dwDebugEventCode==6){
									printf(" LOAD_DLL_DEBUG_EVENT      ");
									fprintf(fp," LOAD_DLL_DEBUG_EVENT      ");
								}
								else if(pde->dwDebugEventCode==7){
									printf(" UNLOAD_DLL_DEBUG_EVENT    ");
									fprintf(fp," UNLOAD_DLL_DEBUG_EVENT    ");
								}
								else if(pde->dwDebugEventCode==8){
									printf(" OUTPUT_DEBUG_STRING_EVENT ");
									fprintf(fp," OUTPUT_DEBUG_STRING_EVENT ");	
								}
								else if(pde->dwDebugEventCode==9){
									printf(" RIP_EVENT                 ");
									fprintf(fp," RIP_EVENT                 ");
								}
			printf("\n");
			
		printf("  %08x: %s", ctx.Eip, asm_string); 
		fprintf(fp,"  %08x: %s", ctx.Eip, asm_string);
       printf("         Exception: %08x \n",pde->u.Exception.ExceptionRecord.ExceptionAddress);
	   fprintf(fp,"         Exception: %08x ",pde->u.Exception.ExceptionRecord.ExceptionAddress);
	   printf("                                            [PID:%d, TID:%d]  ",
              pde->dwProcessId, pde->dwThreadId);
       fprintf(fp,"  [PID:%d, TID:%d]  ",
              pde->dwProcessId, pde->dwThreadId);
       printf("   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",
              ctx.Eax, ctx.Ecx, ctx.Edx, ctx.Ebx);
	   fprintf(fp,"   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",
              ctx.Eax, ctx.Ecx, ctx.Edx, ctx.Ebx);
       printf("         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",
              ctx.Esi, ctx.Edi, ctx.Esp, ctx.Ebp);
	  fprintf(fp,"         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",
              ctx.Esi, ctx.Edi, ctx.Esp, ctx.Ebp);
 SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 160); //���� ������ �ǵ�����
       SetThreadContext(thread_handler, &ctx);
        
      //SetThreadContext�� ����  �������͸� Write �� �� �ִ�.
       CloseHandle(thread_handler);
       CloseHandle(process_hander);
      
	   //>>>>>>>>>>>>>>>>>>>>>>>>>>>>
	   fclose(fp); 
	   //>>>>>>>>>>>>>>>>>>>>>>>>>>
       return 0;
}// End of exception_debug_event

//-------------------------------------------------------------------------------------------------
// Main Function

int APIENTRY WinMain(HINSTANCE hInstance,HINSTANCE hPrevInstance,LPSTR lpszCmdParam,int nCmdShow)
{
	DialogBox(hInstance, MAKEINTRESOURCE(IDD_MAIN_DIALOG), HWND_DESKTOP, MainDlgProc);
	return 0;
}



BOOL CALLBACK MainDlgProc(HWND hDlg, UINT iMessage, WPARAM wParam, LPARAM lParam)
{
	char buffer[500000]; //Exception case ���� ���� �� buffer
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
    CONTEXT ctx;
     ctx.ContextFlags= CONTEXT_ALL;

       STARTUPINFO startup_info;
       PROCESS_INFORMATION process_info;
	    // ������ ���μ����� ������ �����  ����ü�� ����
	memset(&process_info, 0, sizeof(process_info));
	// startup_info ����ü�� ������ ����
	memset(&startup_info, 0, sizeof(startup_info));
	startup_info.cb= sizeof(STARTUPINFO);
	int process_counter = 0;//���μ��� ī���� ����
	
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
	switch(iMessage)
	{
		case WM_INITDIALOG:
			hButtonOpenFileDialog = GetDlgItem(hDlg, IDC_PUSHBUTTON_OPENFILEDIALOG);
			hEditFileToBeOpened = GetDlgItem(hDlg, IDC_EDIT_FILETOBEOPENED);
			return TRUE;
		
		case WM_COMMAND:
			switch (LOWORD(wParam))
			{
				case IDC_PUSHBUTTON_OPENFILEDIALOG:
					//----------------------------------------------------------------
					// OPENFILENAME�� ������ ������� ���� ����
					memset(&OFN, 0, sizeof(OPENFILENAME));
					OFN.lStructSize = sizeof(OPENFILENAME);
					OFN.hwndOwner = hDlg;
					OFN.lpstrFilter = L"All Files(*.*)\0*.*\0";
					OFN.lpstrFile = szFileName;
					OFN.nMaxFile = nFileNameMaxLen;
					//----------------------------------------------------------------
					// ���Ͽ��� ��ȭ���ڸ� ����, ���õ� ������ �̸��� ����Ʈ �ڽ��� ����
					if (0 != GetOpenFileName(&OFN))
					{
						SetWindowText(hEditFileToBeOpened, OFN.lpstrFile);
						
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++	
						AllocConsole(); //�ܼ�â open
						freopen("CONIN$", "r", stdin); 
						freopen("CONOUT$", "w", stdout); 
						freopen("CONOUT$", "w", stderr);

						//+++++++++++++++++++File In&out control++++++++++++++++++++++++++++++++++++++++++++
						  time_t timer;
						  struct tm *t;

						  timer = time(NULL); // ���� �ð��� �� ������ ���

						  t = localtime(&timer); // �� ������ �ð��� �и��Ͽ� ����ü�� �ֱ�
						
						char file_name[256];
						sprintf(file_name, "data_%d%d%d%d%d%d.txt",t->tm_year + 1900,t->tm_mon + 1,t->tm_mday,t->tm_hour,t->tm_min,t->tm_sec);
						 //����ð��� ������ �޾� ���� �̸��� ���
						//���� ��,��,��,��,��,��
						FILE *fp = fopen( file_name, "wt" );
						if (fp == NULL) {
							fprintf(fp, "This is log file");
						}
						FILE *fpex = fopen("exception_temp.txt", "w+");
						if (fpex == NULL) {
							fprintf(fpex,"Begin_to_Exception_case");
						}
						//++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++

SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 4); //LOGO

printf("     Bu                                                                                         YBi     \n");
printf("     B  iLBsJi                             iPuYBv    jB    uUvPq iB   B    kB      Sq      BV    Si     \n");
printf("     B    B                                Xu  rB    Bji      Vr iB   B    Bji     BU      UQ    Ki     \n");
printf("     B    B    iUUs   ikuJi  vLiIY rIv     Vv       ivij     iK   B   B   viis    viiv    Yiiv   Ki     \n");
printf("     B    B    B  uV  Ji iB  uK  BJ  Bi    Vv       U  B     Bi  iB   B   I  B    B  B    Q  V   Pi     \n");
printf("     Q    B   iB  sK     iB  su  ur  Bi    kL rsB   B  Ji   vk    B   B   B  ji   B  ui  iU  Q   Ki     \n");
printf("     B    B   iBirii  sUiiB  Ju  Vr  Bi    Sv   B  iQriUs   Bi   iB   B  iQiiBv  rQiiBv  vBiiBr  Pi     \n");
printf("     B    B   iQ      B   B  jk  Sv  Bi    Su   B  uv iiB  vs    iB   B  uv  iB  Ui iiV  ki  iI  Xi     \n");
printf("     B    B    UJvQv  VuisB  VX  EJ  Br    iKuvBr  B    Bi BUYjI  uIvXL  B    Bi B    BiiB    Qi Ki     \n");
printf("     B                                                                                           Si     \n");
printf("     Bu                                                                                         JBi     \n");


							
						BOOL r = CreateProcess(
							NULL,OFN.lpstrFile, NULL, NULL, FALSE, 
							NORMAL_PRIORITY_CLASS | CREATE_SUSPENDED | DEBUG_PROCESS,
							NULL, NULL, &startup_info, &process_info);
						if(!r)
							return -1;

						ResumeThread(process_info.hThread);
		
						do{
              DEBUG_EVENT dbg_event;
              if(!WaitForDebugEvent(&dbg_event, INFINITE)) break;
               //EXCEPTION_DEBUG_EVENT �߻� �� ����ſ��� ���� ���ܸ� ó��
              DWORD dwContinueStatus = DBG_CONTINUE;
              

              switch(dbg_event.dwDebugEventCode)
              {
              case CREATE_PROCESS_DEBUG_EVENT://����� �̺�Ʈ �������� Switch Case �� ����
								 SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 96);
								printf("  EventCode: %d ", dbg_event.dwDebugEventCode);
								fprintf(fp,"  EventCode: %d ", dbg_event.dwDebugEventCode);
								SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 189);
			
								if(dbg_event.dwDebugEventCode==1){
									printf(" EXCEPTION_DEBUG_EVENT     ");
									fprintf(fp," EXCEPTION_DEBUG_EVENT     ");
								}
								else if(dbg_event.dwDebugEventCode==2){
									printf(" CREATE_THREAD_DEBUG_EVENT ");
									fprintf(fp," CREATE_THREAD_DEBUG_EVENT ");
								}
								else if(dbg_event.dwDebugEventCode==3){
									printf(" CREATE_PROCESS_DEBUG_EVENT");
									fprintf(fp," CREATE_PROCESS_DEBUG_EVENT");
								}
								else if(dbg_event.dwDebugEventCode==4){
									printf(" EXIT_THREAD_DEBUG_EVENT   ");
									fprintf(fp," EXIT_THREAD_DEBUG_EVENT   ");
								}	
								else if(dbg_event.dwDebugEventCode==5){
									printf(" EXIT_PROCESS_DEBUG_EVENT  ");
									fprintf(fp," EXIT_PROCESS_DEBUG_EVENT  ");
								}
								else if(dbg_event.dwDebugEventCode==6){
									printf(" LOAD_DLL_DEBUG_EVENT      ");
									fprintf(fp," LOAD_DLL_DEBUG_EVENT      ");
								}
								else if(dbg_event.dwDebugEventCode==7){
									printf(" UNLOAD_DLL_DEBUG_EVENT    ");
									fprintf(fp," UNLOAD_DLL_DEBUG_EVENT    ");
								}
								else if(dbg_event.dwDebugEventCode==8){
									printf(" OUTPUT_DEBUG_STRING_EVENT ");
									fprintf(fp," OUTPUT_DEBUG_STRING_EVENT ");	
								}
								else if(dbg_event.dwDebugEventCode==9){
									printf(" RIP_EVENT                 ");
									fprintf(fp," RIP_EVENT                 ");
								}

			
									SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 160);
									printf("  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									fprintf(fp,"  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									printf("   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									fprintf(fp,"   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									printf("         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);
									fprintf(fp,"         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);
									process_counter++;
											  break;

              case EXIT_PROCESS_DEBUG_EVENT:
								 SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 96);
           						 printf("  EventCode: %d ", dbg_event.dwDebugEventCode);
								 fprintf(fp,"  EventCode: %d ", dbg_event.dwDebugEventCode);
								 SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 189);
								if(dbg_event.dwDebugEventCode==1){
									printf(" EXCEPTION_DEBUG_EVENT     ");
									fprintf(fp," EXCEPTION_DEBUG_EVENT     ");
								}
								else if(dbg_event.dwDebugEventCode==2){
									printf(" CREATE_THREAD_DEBUG_EVENT ");
									fprintf(fp," CREATE_THREAD_DEBUG_EVENT ");
								}
								else if(dbg_event.dwDebugEventCode==3){
									printf(" CREATE_PROCESS_DEBUG_EVENT");
									fprintf(fp," CREATE_PROCESS_DEBUG_EVENT");
								}
								else if(dbg_event.dwDebugEventCode==4){
									printf(" EXIT_THREAD_DEBUG_EVENT   ");
									fprintf(fp," EXIT_THREAD_DEBUG_EVENT   ");
								}	
								else if(dbg_event.dwDebugEventCode==5){
									printf(" EXIT_PROCESS_DEBUG_EVENT  ");
									fprintf(fp," EXIT_PROCESS_DEBUG_EVENT  ");
								}
								else if(dbg_event.dwDebugEventCode==6){
									printf(" LOAD_DLL_DEBUG_EVENT      ");
									fprintf(fp," LOAD_DLL_DEBUG_EVENT      ");
								}
								else if(dbg_event.dwDebugEventCode==7){
									printf(" UNLOAD_DLL_DEBUG_EVENT    ");
									fprintf(fp," UNLOAD_DLL_DEBUG_EVENT    ");
								}
								else if(dbg_event.dwDebugEventCode==8){
									printf(" OUTPUT_DEBUG_STRING_EVENT ");
									fprintf(fp," OUTPUT_DEBUG_STRING_EVENT ");	
								}
								else if(dbg_event.dwDebugEventCode==9){
									printf(" RIP_EVENT                 ");
									fprintf(fp," RIP_EVENT                 ");
								}

			
									SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 160);
									printf("  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									fprintf(fp,"  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									printf("   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									fprintf(fp,"   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									printf("         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);
									fprintf(fp,"         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);
								process_counter--;
								break;

              case EXCEPTION_DEBUG_EVENT:
								  if(dbg_event.u.Exception.ExceptionRecord.ExceptionCode !=
										 EXCEPTION_BREAKPOINT)
								  {
										 dwContinueStatus = DBG_EXCEPTION_NOT_HANDLED;
								  }
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
									exception_debug_event(&dbg_event);  //exception �߻� �� log ���Ͽ� ��,�Ʒ� ó�� ����ǥ �����Ͽ� ������ ������
									fgets(buffer,sizeof(buffer), fpex);
									fprintf(fp,buffer,sizeof(buffer));
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
									fprintf(fp,"!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!\n");
								//execption_debug_event �Լ� ���� �������� ���� �ٽ� �� �ʿ䰡 �����Ƿ�
								// SetThreadContext �Լ��� ȣ�� �� �ʿ䰡 �������� �ȴ�.
								break;


				default :
									SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 96);
									printf("  EventCode: %d ", dbg_event.dwDebugEventCode);
									fprintf(fp,"  EventCode: %d ", dbg_event.dwDebugEventCode);
									SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 189);
			
									if(dbg_event.dwDebugEventCode==1){
									printf(" EXCEPTION_DEBUG_EVENT     ");
									fprintf(fp," EXCEPTION_DEBUG_EVENT     ");
								}
								else if(dbg_event.dwDebugEventCode==2){
									printf(" CREATE_THREAD_DEBUG_EVENT ");
									fprintf(fp," CREATE_THREAD_DEBUG_EVENT ");
								}
								else if(dbg_event.dwDebugEventCode==3){
									printf(" CREATE_PROCESS_DEBUG_EVENT");
									fprintf(fp," CREATE_PROCESS_DEBUG_EVENT");
								}
								else if(dbg_event.dwDebugEventCode==4){
									printf(" EXIT_THREAD_DEBUG_EVENT   ");
									fprintf(fp," EXIT_THREAD_DEBUG_EVENT   ");
								}	
								else if(dbg_event.dwDebugEventCode==5){
									printf(" EXIT_PROCESS_DEBUG_EVENT  ");
									fprintf(fp," EXIT_PROCESS_DEBUG_EVENT  ");
								}
								else if(dbg_event.dwDebugEventCode==6){
									printf(" LOAD_DLL_DEBUG_EVENT      ");
									fprintf(fp," LOAD_DLL_DEBUG_EVENT      ");
								}
								else if(dbg_event.dwDebugEventCode==7){
									printf(" UNLOAD_DLL_DEBUG_EVENT    ");
									fprintf(fp," UNLOAD_DLL_DEBUG_EVENT    ");
								}
								else if(dbg_event.dwDebugEventCode==8){
									printf(" OUTPUT_DEBUG_STRING_EVENT ");
									fprintf(fp," OUTPUT_DEBUG_STRING_EVENT ");	
								}
								else if(dbg_event.dwDebugEventCode==9){
									printf(" RIP_EVENT                 ");
									fprintf(fp," RIP_EVENT                 ");
								}

			
									SetConsoleTextAttribute( GetStdHandle(STD_OUTPUT_HANDLE), 160);
									printf("  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									fprintf(fp,"  [PID:%d, TID:%d]  ", process_info.dwProcessId,process_info.dwThreadId);
									printf("   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									fprintf(fp,"   Reg: EAX=%08x ECX=%08x EDX=%08x EBX=%08x",&ctx.Eax,&ctx.Ecx,&ctx.Edx,&ctx.Ebx);
									printf("         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);
									fprintf(fp,"         ESI=%08x EDI=%08x ESP=%08x EBP=%08x\n",&ctx.Esi,&ctx.Edi,&ctx.Esp,&ctx.Ebp);  
									  }
 
              ContinueDebugEvent(
                      dbg_event.dwProcessId, dbg_event.dwThreadId, dwContinueStatus);
 
       }while(process_counter > 0);
		CloseHandle(process_info.hThread); //Thread ����
       CloseHandle(process_info.hProcess); // Process ����
	   
	   
		fclose(fpex); 
	   fclose(fp); 
	   
	   FreeConsole(); // �ܼ�����
//+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++
					}
					return TRUE;    
					

			}
			return FALSE;
			

			case WM_CLOSE:
				
			EndDialog(hDlg, IDOK);
			return TRUE;
	}


	return FALSE;
}
